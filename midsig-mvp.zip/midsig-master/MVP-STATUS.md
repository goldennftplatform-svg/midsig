# MIDSIG paid-postage MVP snapshot

This snapshot hardens and completes the core MVP path without deploying anything.

## Enforced MVP contract

A paid gateway accepts/stores a message only when:

1. the RFC5322 From domain has a valid `_midsig` DNS key;
2. the message carries a valid MIDSIG v2 signature;
3. the v2 signature binds the message body and SMTP envelope recipient(s);
4. the enrolled domain/key matches the paid ledger account; and
5. the account has at least 0.05 USDC-equivalent stamp credit per new envelope recipient.

The ledger debit and durable message storage happen in one SQLite transaction. Exact retries do not charge twice; Message-ID reuse with changed signed content is rejected.

## Security changes in this snapshot

- Milter now collects real SMTP `RCPT TO` recipients and body chunks. Paid postage never trusts visible To/Cc headers for charging.
- MIDSIG v2 signs a canonical body digest and privacy-preserving SHA-256 recipient commitments. A captured signed message cannot simply be sprayed to recipients that were not authorized by the sender.
- Paid gateways reject legacy MIDSIG v1 because v1 does not bind content or envelope recipients.
- Privy JWTs are cryptographically verified with the configured ES256 public verification key and `exp`/issuer/audience checks. Set `MIDSIG_PRIVY_VERIFICATION_KEY` to the PEM verification key from the Privy dashboard. The API fails closed if it is missing.
- Domain enrollment is now a two-step DNS ownership proof. A public `_midsig` key by itself cannot be claimed by an arbitrary logged-in user. The API returns a `_midsig-verify.<domain>` TXT challenge that must be published before activation.
- Card checkout no longer auto-claims domains from public DNS.
- Base USDC settlement requires successful receipt plus configurable confirmations (`MIDSIG_BASE_CONFIRMATIONS`, default 2).
- MVP crypto checkout is Base-only. Solana remains future work rather than presenting an uncreditable route as live.

## Deliberately not claimed

- This does not change Gmail/Yahoo or global SMTP policy. It protects gateways that deploy MIDSIG enforcement.
- SPF/DKIM/DMARC are complementary controls; this snapshot does not itself implement those protocols. The production MTA/Rspamd deployment must enforce them in the trusted mail pipeline.
- The blockchain is used for prepaid settlement, not for publishing email contents or raw Message-IDs.
- Production deployment, DNS changes, Privy key configuration, Square credentials, Base receiver custody, backups, monitoring, TLS, and MX cutover are operational steps and were not performed by this offline build.

## Test result in build workspace

`pytest -q`: 33 passed, 2 subtests passed.

`node --test tests/test_postage_model.mjs`: 5 passed.

RFC 8032 Ed25519 local vectors pass. The vector script's optional live DoH flow was not exercised in the offline build environment.
